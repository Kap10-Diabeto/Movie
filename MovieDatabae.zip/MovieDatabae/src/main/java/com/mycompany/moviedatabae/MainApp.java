package com.mycompany.moviedatabae;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import com.mycompany.moviedatabae.Movie;
import com.sun.java.swing.plaf.windows.resources.windows;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;



public class MainApp extends Application {
    
    TableView<Movie> table;
    Stage window;
    TextField titleInput, dirInput;

    @Override
    public void start(Stage stage) throws Exception {
        window = stage;
        window.setTitle(("Movies"));
        
        
        //Parent root = FXMLLoader.load(getClass().getResource("/fxml/Scene.fxml"));
        
        //Title column
       TableColumn<Movie, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setMinWidth(250);
        titleColumn.setCellValueFactory(new PropertyValueFactory<Movie, String>("movie"));
        
        //Director column
       TableColumn<Movie, String> RegiColumn = new TableColumn<>("Director");
        RegiColumn.setMinWidth(250);
        RegiColumn.setCellValueFactory(new PropertyValueFactory<Movie, String>("regi"));
        
        //Inputs
        titleInput = new TextField();
        titleInput.setPromptText("Title");
        titleInput.setMinWidth(100);
        
        dirInput = new TextField();
        dirInput.setPromptText("Director");
        dirInput.setMinWidth(100);
        
        //Buttons
        Button addButton = new Button("Add");
        addButton.setOnAction(e-> addButtonClicked());
        Button delButton = new Button("Delete");
        delButton.setOnAction(e-> delButtonClicked());
        
        
        HBox hbox = new HBox();
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.setSpacing(10);
        hbox.getChildren().addAll(titleInput, dirInput, addButton, delButton);
        
        
        
        
       table = new TableView<>();
        table.setItems(getMovie());
        table.getColumns().addAll(titleColumn, RegiColumn);
        
        VBox vBox = new VBox();
        vBox.getChildren().addAll(table, hbox);
        
        Scene scene = new Scene(vBox);
        window.setScene(scene);
        window.show();
        }
        //addButtonClicked
        public void addButtonClicked(){
            Movie mov = new Movie();
            mov.setMovie(titleInput.getText());
            mov.setMovie(dirInput.getText());
            table.getItems().add(movie);
            
        }

       
       /** Scene scene = new Scene(root);
        scene.getStylesheets().add("/styles/Styles.css");
        
        stage.setTitle("JavaFX and Maven");
        stage.setScene(scene);
        stage.show();
        */
    
    
    public ObservableList<Movie> getMovie(){
        ObservableList<Movie> movies = FXCollections.observableArrayList();
        movies.add(new Movie("Kill Bill", "Quentin Tarantino"));
        movies.add(new Movie("The Dark Knight Rises", "Christopher Nolan"));
        movies.add(new Movie("Spirited Away", "Hayao Miyazaki"));
        return movies;
    }
    /**
     * The main() method is ignored in correctly deployed JavaFX application.
     * main() serves only as fallback in case the application can not be
     * launched through deployment artifacts, e.g., in IDEs with limited FX
     * support. NetBeans ignores main().
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }




    
   
    

}
