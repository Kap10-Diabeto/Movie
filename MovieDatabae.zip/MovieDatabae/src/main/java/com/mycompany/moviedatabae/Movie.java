/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.moviedatabae;

/**
 *
 * @author Matteus Psajd
 */
public class Movie {

    private String movie;
    private String regi;

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public String getRegi() {
        return regi;
    }

    public void setRegi(String regi) {
        this.regi = regi;
    }

    public Movie(String movie, String regi) {
        this.movie = movie;
        this.regi = regi;
    }

    public Movie() {
    }

    
    
    
    
}
